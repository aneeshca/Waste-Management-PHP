<?php
	session_start();
	include "db.php";
	
	if(isset($_POST['Email']) && isset($_POST['pass']))
	{
		$name=$_POST['Email'];
		$pass=$_POST['pass'];
	
		$sql="select * from user where name='$name' and password='$pass'";
		$res1=mysqli_query($con,$sql) or die(mysqli_error($con));
	
		if(mysqli_num_rows($res1)==1){
			echo 1;
		}else{
			echo 0;
	
		}
	
	}
	?>

