<?php
include "header.php";
?>

<div class="wrapper ">    
<?php
include "nav-bar.php";
?>    
 <div class="content">
<div class="container-fluid">







<br>
<h3>Hello Im here Staff</h3>





</div>
</div>
<?php
include "footer.php"
?>
</div>