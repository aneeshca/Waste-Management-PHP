	<?php
    include "header.php";
	?>
	<?php
	include "db.php";
	?>
    	
<div class="container">
<div class="main-agile">
    <!-- book -->
	<div class="banner-bottom-w3l" id="book"></div>
	<div class="testimonials">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>B</span>ook Now
				</h3>
				<div class="tittle-style">
				</div>
			</div>
<div class="second-contact-agile">
		<div class="col-md-6 form-bg">

		
<?php 

  include "db.php";
  $email = "";
  

  if (isset($_POST['save'])) {
	
  	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$district = $_POST['district'];
	$pinnumber = $_POST['pinnumber'];
	$address = $_POST['address'];
  	
  
  	$sql_ee = "SELECT * FROM userb WHERE email='$email'";
  	
  	$res_ee = mysqli_query($con, $sql_ee);

  		
  	if(mysqli_num_rows($res_ee) > 0){
  	  $_SESSION["error"] = "Sorry... email already taken"; 	
        header("location:book-now.php");
  	}else{
           $query1 = "INSERT INTO userb (name, email, phone, district, pinnumber, address) 
      	    	  VALUES ('$name', '$email', '$phone', '$district', '$pinnumber', '$address')";
           $results = mysqli_query($con, $query1);
           $_SESSION["error"] = "";
           header("location:");
           exit();
  	}
  }
?>



			<form action="#" method="post">
				<div class="contact-fields">
					<input type="text" name="name" placeholder="Name" required="">
				</div>
				<div class="contact-fields">
					<input type="email" name="email" placeholder="Email" required="">
				</div>
				<div class="contact-fields">
					<input type="number" name="Phone" placeholder="Phone number" required="">
				</div>
				<div class="contact-fields">
					<input type="text" name="district" placeholder="District" required="">
				</div>	
				<div class="contact-fields">
					<input type="text" name="pinnumber" placeholder="Pin Number" required="">
				</div>	
				<div class="contact-fields">
					<textarea name="address" placeholder="address" required=""></textarea>
				</div>
				<input type="submit" name="save" value="Submit">
				
			</form>
	




		
		<div class="clearfix"> </div>
		</div>
	</div>
    </div>
	<!-- //book -->
</div>
</div>

    <?php
   // include "footer.php";
        ?>