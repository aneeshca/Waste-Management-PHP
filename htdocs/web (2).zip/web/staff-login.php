<?php
    include "header.php";
    ?>
<div class="container">
<div class="main-agile">
    <!-- book -->
	<div class="banner-bottom-w3l" id="book"></div>
	<div class="testimonials">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>L</span>ogin
				</h3>
				<div class="tittle-style">
				</div>
			</div>
	<div class="second-contact-agile">
		<div class="col-md-6 form-bg">
			<form action="#" method="post">
				<div class="contact-fields">
					<input type="email" name="Email" placeholder="Email" required="">
				</div>
				<div class="contact-fields">
					<input type="password" name="pass" placeholder="Password" required="">
				</div>	
				<input type="submit" value="Submit">
			</form>
		</div>
		<div class="clearfix"> </div>
		</div>
	</div>
    </div>
	<!-- //book -->
</div>
</div>

    <?php
   // include "footer.php";
        ?>