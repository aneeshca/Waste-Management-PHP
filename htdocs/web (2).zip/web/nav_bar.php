<div class="agile-top">
			<div class="col-xs-4 logo">
				<h1>
					<a href="index.html">
						<span>Green Kerala</span>
						
				</h1>
			</div>
			<div class="col-xs-6 header-w3l">
				<ul>
					<li>
						<a href="#" data-toggle="modal" data-target="#myModal1">
							<span class="fa fa-unlock-alt" aria-hidden="true"></span> Admin </a>
					</li>
					<li>
						<a href="#" data-toggle="modal" data-target="#myModal2">
							<span class="fa fa-pencil-square-o" aria-hidden="true"></span> Staff </a>
					</li>
				</ul>
			</div>
			
			<!-- navigation -->
			<div class="col-xs-2 menu">
				<a href="" id="menuToggle">
					<span class="navClosed"></span>
				</a>
				<nav>
					<a href="index.php">Home</a>
					<!-- <a href="#about" class="scroll">About Us</a>
					<a href="#services" class="scroll">Our Aim</a> -->
                    <a href="login.php">Book Now</a>
					<!--<a href="book-now.php">login</a> -->
				</nav>
			</div>
			<!-- //navigation -->
		</div>