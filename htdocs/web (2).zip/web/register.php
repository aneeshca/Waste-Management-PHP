<?php 
session_start();
  include "db.php";
  $name = "";
  $email = "";
  if (isset($_POST['save'])) {
  	$name = $_POST['name'];
  	$email = $_POST['email'];
  	$password = $_POST['password'];
  
  	$sql_e = "SELECT * FROM user WHERE email='$email'";
  	
  	$res_e = mysqli_query($con, $sql_e);

  		
  	if(mysqli_num_rows($res_e) > 0){
  	  $_SESSION["error"] = "Sorry... email already taken"; 	
        header("location:sign-up.php");
  	}else{
           $query = "INSERT INTO user (name, email, password) 
      	    	  VALUES ('$name', '$email', '".md5($password)."')";
           $results = mysqli_query($con, $query);
           $_SESSION["error"] = "";
           header("location:login.php");
           exit();
  	}
  }
?>
