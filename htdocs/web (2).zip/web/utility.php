<div class="form-group">
			<label class="form-check-label"><input type="checkbox" required="required">


            <div class="form-group">
            <input type="password" class="form-control" name="cpass" placeholder="Confirm Password" required="required">
        </div>