<?php if(!isset($_SESSION['name']));
header("location:http://localhost/web/index.php");

?>