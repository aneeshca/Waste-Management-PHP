<?php

$con=mysqli_connect('localhost','root','','waste') or die(mysqli_error($con));

?>