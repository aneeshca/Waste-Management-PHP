
	<div class="slider">
		<div class="callbacks_container">
			<ul class="rslides callbacks callbacks1" >
				<li>

				<div class="col-xs-2 menu" >
				<a href="" id="menuToggle">
					<span class="navClosed"></span>
				</a>
				<nav>
				    <a href="user.php">main page</a>
					<a href="userprofile.php">profile</a>
					<a href="book-now.php">Book Now</a>
					<a href="booking-status.php">booking status</a>
					<a href="web/feedback.php" >Team</a>
					<a href="feedback.php" >Feedback</a>
					<a href="logout.php" class="">logout</a>
					
				</nav>
				</div>
				
			</div>
			<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>