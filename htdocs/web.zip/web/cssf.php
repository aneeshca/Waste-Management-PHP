<?php
include "header.php";
?>
<style>
h2 {
	margin:auto;
	margin-bottom: 20px;
	color:greenyellow;
}

input, textarea {
	padding: 10px;
	border: 1px solid #E5E5E5;
	width: 200px;
	color:green;
	box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px;
	-moz-box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px;		
}

textarea {
	margin-left:19px;
	width: 400px;
	height: 150px;
	max-width: 400px;
	line-height: 18px;
}

input:hover, textarea:hover,
input:focus, textarea:focus {
	border-color: 1px solid #C9C9C9;
	box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 8px;
	-moz-box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 8px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 8px;	
}

.form label {
	margin-left: 10px;
	font-family:cursive;
}
.button_submit input {
	margin:center;
	width: 100px; 
	font-size:18px;
	font-family:cursive;
	background-color:red; 
	color:blue;
	border-radius: 3px;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border: 1px sol blue;
}
label{
	margin:auto;
	margin-bottom: 20px;
	color:green;
}

</style>